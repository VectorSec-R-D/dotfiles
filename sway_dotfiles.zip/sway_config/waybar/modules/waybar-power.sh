#!/bin/sh
swaynag -t custom -m 'Are you sure you want to shutdown your device?' -b 'Poweroff' 'sudo poweroff'
