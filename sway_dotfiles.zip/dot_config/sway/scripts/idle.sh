#!/bin/sh
exec swayidle \
	timeout 180 'swaylock -f -C ~/.config/swaylock/config' \
	timeout 240 'swaymsg "output * dpms off"' \
	timeout 15 'if pgrep -x swaylock; then swaymsg "output * dpms off"; fi' \
	resume 'swaymsg "output * dpms on"; sleep 2; swaymsg "output * enable"' 
        
