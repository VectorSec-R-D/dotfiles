#!/bin/sh
date +"%a %d"
