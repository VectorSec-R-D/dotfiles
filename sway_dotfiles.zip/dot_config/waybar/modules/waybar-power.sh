#!/bin/sh
swaynag -t warning -m 'Power Menu Options' -b 'logout' 'swaymsg exit' -b 'hibernate' 'swaymsg exec sudo ZZZ' -b 'shutdown' 'swaymsg exec sudo poweroff' -b 'reboot' 'swaymsg exec sudo reboot'
